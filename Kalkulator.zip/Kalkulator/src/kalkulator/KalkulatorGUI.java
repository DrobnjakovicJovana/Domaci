/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kalkulator;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author Drobnjakovic
 */
public class KalkulatorGUI {
    private JFrame jf;
    private JPanel jp;
     private JButton jbtnIzracunaj;
    private JComboBox jComboBoxOperacija;
    private JLabel jlblPrviBroj;
    private JLabel jlblDrugiBroj;
    private JLabel jlblOperacija;
    private JLabel jlblRezultat;
    private JTextField jtxtPrviBroj;
    private JTextField jtxtDrugiBroj;
    private JTextField jtxtRezultat;
    private JButton   jbtnResetuj;
    
    public KalkulatorGUI(){
    podesavanja();
    }
    public void podesavanja(){
        jf=new JFrame("Kalkulator");
        jf.setSize(500,500);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setResizable(true);
        jf.setLocationRelativeTo(null);
        jp = new JPanel(new GridBagLayout());
        
    jlblPrviBroj  = new JLabel("Prvi broj");
    jlblDrugiBroj = new JLabel("Drugi broj:");
    jbtnIzracunaj = new JButton("Izracunaj");
      jbtnResetuj = new JButton("Resetuj");
    jlblOperacija = new JLabel("Izaberi operaciju");
   jlblRezultat = new JLabel("Rezultat je:");
   jtxtPrviBroj = new JTextField(null, 10);
   jtxtDrugiBroj = new JTextField(null,10);
   jtxtRezultat = new JTextField(null,10);
   jComboBoxOperacija = new JComboBox();
   jComboBoxOperacija.addItem("+");
   jComboBoxOperacija.addItem("/");
    jComboBoxOperacija.addItem("-");
     jComboBoxOperacija.addItem("*");
     
      jtxtRezultat.setEditable(false);
      
      jbtnIzracunaj.addActionListener(
              new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               double prvi, drugi, treci;
            try{
               prvi = Double.parseDouble(jtxtPrviBroj.getText());
               drugi = Double.parseDouble(jtxtDrugiBroj.getText());
                 treci = prvi+drugi;
                 //posto je difoltu znak plus
               if(jComboBoxOperacija.getSelectedItem()== "/"){
               treci = prvi/drugi;
               }
                if(jComboBoxOperacija.getSelectedItem()== "*"){
               treci = prvi*drugi;
               }
                 if(jComboBoxOperacija.getSelectedItem()== "-"){
               treci = prvi-drugi;
               }
                  if(jComboBoxOperacija.getSelectedItem()== "+"){
               treci = prvi+drugi;
               }
               jtxtRezultat.setText(""+treci);
            }
            catch(Exception ex){
            JOptionPane.showMessageDialog(null,"Doslo je do greske, proverite da li ste uneli oba broja");
            }
            }
        }
      );
      
      
       jbtnResetuj.addActionListener(
              new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              
            try{
              jtxtPrviBroj.setText("");
              jtxtDrugiBroj.setText("");
              jtxtRezultat.setText("");}
            catch(Exception ex1){
            JOptionPane.showMessageDialog(null,"Greska!");
            }
            
            }}
      );
      
      
              
        GridBagConstraints gb = new GridBagConstraints();
        gb.insets = new Insets(20, 5, 20, 5);
        gb.gridx = 0;
        gb.gridy = 0;
        jp.add(jlblPrviBroj,gb);
        gb.gridx = 1;
        gb.gridy = 0;
        jp.add(jtxtPrviBroj,gb);
        
        
        gb.gridx = 0;
        gb.gridy = 2;
         jp.add(jlblDrugiBroj,gb);
         gb.gridx = 1;
        gb.gridy = 2;
         jp.add(jtxtDrugiBroj,gb);
         
            gb.gridx = 0;
        gb.gridy = 3;
         jp.add(jlblOperacija,gb);
         gb.gridx =1;
        gb.gridy = 3;
         jp.add(jComboBoxOperacija,gb);
         
         
            gb.gridx = 0;
        gb.gridy = 4;
         jp.add(jbtnIzracunaj,gb);
          gb.gridx = 0;
        gb.gridy = 5;
         jp.add(jbtnResetuj,gb);
         
         gb.gridx = 1;
        gb.gridy =4;
         jp.add(jtxtRezultat,gb);
            gb.gridx = 0;
       
         
         
         
         jf.add(jp);
         jf.setVisible(true);
         
      
        
        
   
    }
   
}

